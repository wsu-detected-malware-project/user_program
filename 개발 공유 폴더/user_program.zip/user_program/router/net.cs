using DotNetEnv;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;


namespace user_program{
    public class net{
    public static async Task RunAsync(){

        Env.Load(@"C:\Users\ljw01\Desktop\user_program\.env");
        string filePath = Env.GetString("FILEPATH", "default_filepath");
        string url = Env.GetString("URL", "default_url");
        string savePath = @"C:\Users\ljw01\Desktop\user_program\./result.csv";

        using(var client = new HttpClient())
        using(var form = new MultipartFormDataContent())
        using(var fileStream = File.OpenRead(filePath))
        using (var fileContent = new StreamContent(fileStream)) {

            fileContent.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
            form.Add(fileContent, "file", Path.GetFileName(filePath));
            try {
                HttpResponseMessage response = await client.PostAsync("http://127.0.0.1:8080/upload", form);
                response.EnsureSuccessStatusCode();

                var resultBytes = await response.Content.ReadAsByteArrayAsync();
                File.WriteAllBytes(savePath, resultBytes);

                Console.WriteLine("파일 저장 완료: " + savePath);
            }
            catch (Exception ex) {
                Console.WriteLine("오류 발생: " + ex.Message);
            }

        }
    }
    }
}