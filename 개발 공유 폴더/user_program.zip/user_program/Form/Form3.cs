using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using user_program.controller;


namespace user_program
{
    public partial class Form3 : Form
    {
        private Controller _controller = Controller.Singleton;

        private string protect_or_malware; // 문자열 인자를 저장할 변수
        private List<string> malwareNames = new List<string>();

        public Form3()
        {
            InitializeComponent();
            _controller.form3 = this;
        }
        public Form3(string _protect_or_malware, List<string> _malwareNames)
        {
            InitializeComponent();
            _controller.form3 = this;

            protect_or_malware = _protect_or_malware;
            malwareNames = _malwareNames;
        }

        // 이미지 로드 함수
        public void LoadImage_Protect()
        {
            // 이미지 경로를 지정 (shield1.jpg의 경로가 프로젝트 폴더 내에 있다고 가정)
            string imagePath = @"C:\Users\pth81\Desktop\user_program\img\shield1.jpg";

            pictureBox1.Image = System.Drawing.Image.FromFile(imagePath);

        }

        public void LoadImage_Malware()
        {
            // 이미지 경로를 지정 (shield1.jpg의 경로가 프로젝트 폴더 내에 있다고 가정)
            string imagePath = @"C:\Users\pth81\Desktop\user_program\img\shield2.jpg";

            pictureBox1.Image = System.Drawing.Image.FromFile(imagePath);

            _controller.C_Test_Print_List(malwareNames);

        }

        bool mouseDown;
        Point lastlocation;
        private void lbl_title_MouseDown(object sender, MouseEventArgs e)
        {
            mouseDown = true;
            lastlocation = e.Location;
        }
        private void lbl_title_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDown = false;
        }

        private void lbl_title_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseDown)
            {
                this.Location = new Point(
                    (this.Location.X - lastlocation.X) + e.X,
                    (this.Location.Y - lastlocation.Y) + e.Y);

                this.Update();
            }
        }

        private void btn_min_Click(object sender, MouseEventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
        private void btn_max_Click(object sender, MouseEventArgs e)
        {
            if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Maximized;
            }
            else
            {
                this.WindowState = FormWindowState.Normal;
            }
        }

        private void btn_close_Click(object sender, EventArgs e)
        {

            this.Close();
        }

        private void btn_close_Click(object sender, MouseEventArgs e)
        {
            this.Close();
        }

        private void lbl_title_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }
        private void Form3_Load(object sender, EventArgs e)
        {
            if (protect_or_malware == "protect")
            {
                _controller.C_Print_Image_Protect();
            }
            else if (protect_or_malware == "malware")
            {
                _controller.C_Print_Image_Malware();  // p_invest 관련 처리
                //_controller.C_Test_Print_List();
            }
        }


        //Form3 검사 내역 출력
        public void Test_Print_List(List<string> msg)
        {
            this.Show();

            foreach (var name in msg)
            {
                listBox1.Items.Add(name);
            }    
        }


    }
}
